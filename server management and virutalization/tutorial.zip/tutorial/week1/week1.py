'''
#qno:1
def fib():
    n = int(input("Enter the number of terms: ")) 
    if n <= 0:
        print("Please enter a positive integer.")
        return
    
    a, b = 0, 1  
    for _ in range(n):
        print(a, end=" ")  
        a, b = b, a + b  
    print() 

fib()
'''
"""
#QNO:2
def myPow(x, n):
    result = 1  
    while n > 0:
        result *= x 
        n -= 1 
    return result

base = float(input("Enter base (x): "))
exp = int(input("Enter exponent (n): "))

if exp < 0:
    print("Please enter a non-negative integer for the exponent.")
else:
    print(f"{base}^{exp} =", myPow(base, exp))
"""

'''
#qno3
def SumDigits(n):
    n = abs(int(n))  
    digit_sum = 0
    
    while n > 0:
        digit_sum += n % 10  
        n //= 10  # Remove the last digit
    
    print("Sum of digits:", digit_sum)

# Example usage
num = int(input("Enter a number: "))
SumDigits(num)
'''
'''
#qno:4

def squaredSum(arr):
    total = 0  
    
    for num in arr:  
        total += num * num  
    
    return total  


numbers = [2, 3, 4]
print("Sum of squares:", squaredSum(numbers))
'''

#qno:5
def sumDigits(num):
    num = abs(num)  
    digit_sum = 0
    
    while num > 0:
        digit_sum += num % 10 
        num //= 10  
    
    return digit_sum

print(sumDigits(234))  
print(sumDigits(6))   
print(sumDigits(1234)) 
print(sumDigits(-567)) 





    
